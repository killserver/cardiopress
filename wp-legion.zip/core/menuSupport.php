<?php
if(!defined("IS_CORE")) { echo "403 Error"; die(); }

register_nav_menus(array(
'menu0' => __('контакты'),
'menu1' => __('соц.сети'),

));