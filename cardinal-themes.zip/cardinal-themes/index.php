<?php
global $tplSite;
templates::display($tplSite);