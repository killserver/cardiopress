<?php
//your code must be after
//add_theme_support("woocommerce");
?>